.test <- function() BiocGenerics:::testPackage("rtracklayer")
