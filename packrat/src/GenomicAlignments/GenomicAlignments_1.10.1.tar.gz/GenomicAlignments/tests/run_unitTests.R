require("GenomicAlignments") || stop("unable to load GenomicRanges package")
GenomicAlignments:::.test()
